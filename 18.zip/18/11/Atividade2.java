import java.util.Scanner;

public class Atividade2 {

    static Scanner s = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("=== Conversor de Meses ===");

        System.out.print("Digite o número de um mês (1 a 12): ");
        int Mes = s.nextInt();
        s.nextLine();

        System.out.print("Deseja o mês 'completo' ou 'abreviado'? ");
        String Tipo = s.nextLine();

        String Resposta = ConverterMes(Mes, Tipo);

        System.out.println("Resultado: " + Resposta);
    }

    public static String ConverterMes(int Mes, String Tipo) {

        String[] MesesCompletos = {
                "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
        };

        String[] MesesAbreviados = {
                "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
                "Jul", "Ago", "Set", "Out", "Nov", "Dez"
        };

        if (Mes < 1 || Mes > 12) {
            return "Mês inválido!";
        }

        if (Tipo.equalsIgnoreCase("Completo")) {
            return MesesCompletos[Mes - 1];

        } else if (Tipo.equalsIgnoreCase("Abreviado")) {
            return MesesAbreviados[Mes - 1];
        }

        return "Tipo inválido! Use 'completo' ou 'abreviado'.";
    }
}