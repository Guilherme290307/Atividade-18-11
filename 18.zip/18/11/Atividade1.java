import java.util.Scanner;

public class Atividade1 {

    static Scanner s = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("=== Cadastro de Pedidos ===");
        String[][] Pedidos = CadastrarPedidos();

        System.out.print("\nDigite o número do pedido para consultar: ");
        String Numero = s.nextLine();

        BuscarPedido(Pedidos, Numero);
    }

    public static String[][] CadastrarPedidos() {

        System.out.print("Quantos pedidos deseja cadastrar? ");
        int Quantidade = s.nextInt();
        s.nextLine();

        String[][] Pedidos = new String[Quantidade][5];

        for (int i = 0; i < Quantidade; i++) {
            System.out.println("\n--- Cadastro do pedido " + (i + 1) + " ---");

            System.out.print("Número do pedido: ");
            Pedidos[i][0] = s.nextLine();

            System.out.print("Nome da cliente: ");
            Pedidos[i][1] = s.nextLine();

            System.out.print("Cor principal: ");
            Pedidos[i][2] = s.nextLine();

            System.out.print("Cor secundária: ");
            Pedidos[i][3] = s.nextLine();

            System.out.print("Cor complementar: ");
            Pedidos[i][4] = s.nextLine();
        }

        return Pedidos;
    }

    public static void BuscarPedido(String[][] Pedidos, String Numero) {
        boolean Achei = false;

        for (int i = 0; i < Pedidos.length; i++) {
            if (Pedidos[i][0].equalsIgnoreCase(Numero)) {
                Achei = true;

                System.out.println("\n=== Dados do Pedido ===");
                System.out.println("Número do pedido: " + Pedidos[i][0]);
                System.out.println("Cliente: " + Pedidos[i][1]);
                System.out.println("Cor principal: " + Pedidos[i][2]);
                System.out.println("Cor secundária: " + Pedidos[i][3]);
                System.out.println("Cor complementar: " + Pedidos[i][4]);
                break;
            }
        }

        if (!Achei) {
            System.out.println("Pedido não encontrado!");
        }
    }
}